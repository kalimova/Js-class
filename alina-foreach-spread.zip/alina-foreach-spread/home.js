// task1  Вам дан массив: [4, 54, 49]. Сделайте из него массив, состоящий из квадратов этих чисел. Используйте foreach

// let arr = [4, 54, 49]
// arr.forEach((el) => {
//     console.log(Math.sqrt(el));
//     })    

// task2 Вам дан массив [3134, 4, -143, -245, -214]. Выведите первое отрицательное число

// let arr = [3134, 4, -143, -245, -214]
// let newArr = arr.find((el) => {
//     return el < 0
// })
// console.log(newArr);


// task3 Вам дан массив [3, 51, 30, 54, 60]. Оставьте в нем только четные числа. Используйте foreach
// let arr = [3, 51, 30, 54, 60]
// let even = []
// arr.forEach((el) => {
// 	console.log(...even, el % 2 === 0)
// });


// task4  Вам дан массив ['Бегимай', 'Баяман', 'Калмамат','Саша'].

//     Оставьте в нем  строку, длина которой больше 5-ти символов.

// let arr = ['Бегимай', 'Баяман', 'Калмамат','Саша']
// let newArr = []
// arr.forEach((el,idx,arr) => {
//  newArr = [...newArr, el.length > 5]
// })
// console.log(newArr);

// task5  Вам дан массив [-13, 96, -41, -28, 40].

//     Посчитайте количество отрицательных чисел в этом массиве. Используйте foreach
// let arr = [-13, 96, -41, -28, 40]
// let newArr = []
// arr.forEach((el) => {
//  newArr = [...newArr, el < 0]
// })
//  console.log(newArr);

// task6  Вам дан массив [3, 51, -30, -54, 60]. Оставьте в нем только положительные числа.

//     Затем возведите в третью степень Используйте foreach

// let arr = [3, 51, -30, -54, 60]
// arr.forEach((el) => {
//   if(el > 0) console.log(el ** 3);
// })

// task7 Вам дан массив [55, 44, 55, 44, 15, 49]. Оставьте в нем первое неповторяющееся число.

// let arr = [55, 44, 55, 44, 15, 49]
// let newArr = arr.find((el) => {
//     return arr.indexOf(el) === arr.lastIndexOf(el)
// })
// console.log(newArr);

// task8 Вам дан массив ['Бегимай', 'Баяман', 'Калмамат']. Выведите длину каждой строки. Используйте foreach
// let arr = ['Бегимай', 'Баяман', 'Калмамат']
// let newArr = []
// arr.forEach((el,idx,arr) => {
//  newArr = [...newArr, el.length]
// })
// console.log(newArr);

