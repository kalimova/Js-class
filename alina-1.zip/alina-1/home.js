// let a = 11
// if (a ===10){
//     console.log(true);
// }
// else{
//     console.log(false);
// }

// let a = 50;
// let b = 100;
// if (a > b) {
//     console.log("a больше b");
// }
// else {
//     console.log("a меньше b");
// }

// let a = 0;
// if (a > 0) {
//     console.log("positive");
// }
// else if (a === 0) {
//     console.log("равно");
// }
// else {
//     console.log("negative");
// }

// let number=45;
// if (number % 2 === 0) {
//     console.log("even");
// } else {
//     console.log("odd");
// }

// let a = 9;
// let b = 2;
// if (a % b === 0) {
//     console.log("even");
// }
// else {
//     console.log("odd");
// }

// let s = true;
// if (typeof s === "boolean"){
//  console.log("boolean");
// }
//  else if (typeof s === "number"){
// console.log("number");
// }
// else {
//  console.log("string");
// }

// let a = 10;
// if (a > 1 && a < 9) {
//     console.log("true");
// }
// else {
//     console.log("false");
// }

// let a = 3;
// if (a ===3 || a === 7) {
//     console.log("a+7");
// } else {
//     console.log("a/10");
// }

// let a =5;                                               не понятно
// let b =10;
// if (a === 0  && a < 0) (b > 5 || b === 5){
// console.log(sum);
// }
// else {
//     console.log(arr)
// }

// let a = 5;                                               не понятно
// let b = 6;
// if (a > 4 && a < 10 || b > 7 || b === 7 && b < 17) {
//     console.log("true");
// } else {
//     console.log("false");
// }

// let month = 8;
// if (month >= 3 && month < 6) {
//     console.log("весна");
// }
// else if (month >= 6 && month < 9) {
//     console.log("лето");
// }
// else if (month >= 9 && month < 12) {
//     console.log("осень");
// }
// else if (month === 1 || month === 2 || month === 12) {
//     console.log("зима");
// }
// else {
//     console.log("false");
// }

// let day = 20;
// if (day >=1 && day <10) {
//     console.log("первая декада");
// }
// else if (day >=10 && day < 20){
//     console.log("вторая декада");
// }
// else if (day >=20 && day < 31){
//     console.log("третья декада");
// }
// else {
//     console.log("false");
// }

// let a='12345';                                               не понятно
// if (str[0]===1 || str[0]===2 || [0]===3) {
//     console.log("Да");
// }
// else {
//     console.log("Нет");
// }

// let age = 21;                                                
// if (age >= 1 && age <5){
//     console.log("Год");
// } else if (age >=21 && age <24) {
//     console.log("Год");
// } else if (age >=5 && age >20) {
//     console.log("Лет");
// } else if (age >=25) {
//     console.log("Лет");
// } else {
//     console.log("false");
//  }

// let time = 61;
// if (time >= 1 && time < 15) {
//   console.log("первая четверть");
// } else if (time >= 15 && time < 30) {
//   console.log("вторая четверть");
// } else if (time >= 30 && time < 45) {
//   console.log("третья четверть");
// } else if (time >= 45 && time < 60) {
//     console.log("четвертая четверть");
// } else {
//   console.log("false");
// }
