// 1 Вам дана переменная age=*любое двузначное число*. Составьте условие, по которому, в консоль будет выводиться "Мне ** год", "Мне ** лет", в зависимости от возраста. Наример мне 21 год, мне 20 лет.

// 2 Вам дана переменная time= *любое чило от 1 до 59*. Составьте условие, по которому время будет делиться на четверти. Пример: time = 12 - Первая четверть. Если число больше 60, то в консоли будет выдаваться "Неверное число".

// 3 вам дана переменная “ADA PROGRAMMING” Выведите длину первого слова.
// 4 Вам даны переменные a = "145",b = "37". Выведите сумму.
// 5. Вам дана переменная a = 1234567. Выведите длину.

// let age = 53;
// if (age > 0 && age < 100 && typeof age === "number") {
//     if (age >= 5 && age <= 20 ) {
//     console.log("мне", age, "год");}
//     else if (age >= 0 && age <= 4 ){
//         console.log("мне", age, "года");}
//     else if (age >= 5 && age <= 20 ){
//         console.log("мне", age, "лет");}
//         else if (age >= 25 && age <= 30 ){
//             console.log("мне", age, "лет");}
//             else if (age >= 31 && age <= 34 ){
//                 console.log("мне", age, "года");}
//                 else if (age >= 35 && age <= 40 ){
//                     console.log("мне", age, "лет");}
//                     else if (age >= 41 && age <= 44 ){
//                         console.log("мне", age, "года");}
//                         else if (age >= 45 && age <= 50 ){
//                             console.log("мне", age, "лет");}
//                             else if (age >= 51 && age <= 54 ){
//                                 console.log("мне", age, "года");}
// } 
// else {
//     console.log("false");
// }


// let time = 55;
// if (time >= 0 && time <= 60 && typeof time ==="number"){
//     if (time >=0 && time <=15){
//     console.log("Первая четверть");}
//     else if (time >=16 && time <=30){
//         console.log("Вторая четверть");}
//         else if (time >=31 && time <=45){
//             console.log("Третья четверть");}
//             else {
//                 console.log("Четвертая четверть");}
// }
// else {
//     console.log("false");
// }

// let a = "ADA";
// let b = " PROGRAMMING"
// console.log(a.length + b);

// let a = "145";
// let b = "37";
// console.log (parseInt(a) + parseInt(b));

// let a = 1234567;
// console.log(a.toString().length)
  


